#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>


void leggi_vettore(double *b,int n);
void stampa_vettore(double *b,int n);

int main (int argc, char *argv[]){

    double *vett,*local_vett;
    int dim, local_dim;
    int nproc,me;
       
    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD,&nproc);
    MPI_Comm_rank(MPI_COMM_WORLD,&me);
    
    if (me==0){
        printf("\n Dimensione del vettore=");
        fflush(stdout);
        scanf("%d",&dim);

        
    	vett=(double *)calloc(dim,sizeof(double));
        printf("\n Inserisci le entrate del vettore vett:\n");
        fflush(stdout);
        leggi_vettore(vett,dim);
      
        local_dim=dim/nproc;
        printf("\n Dimensione locale=%d\n\n",local_dim);
        fflush(stdout);
    }

    MPI_Bcast(&local_dim,1,MPI_INT,0,MPI_COMM_WORLD);
  
    local_vett=(double *)calloc(local_dim,sizeof(double));
       
    MPI_Scatter(&vett[0],local_dim,MPI_DOUBLE,&local_vett[0],local_dim,MPI_DOUBLE,0,MPI_COMM_WORLD);

    
    printf("\n Vettore local_vett sul processo %d",me);
     stampa_vettore(local_vett,local_dim);
         fflush(stdout);
		    
    MPI_Finalize();


}


void leggi_vettore(double *b,int n){

    int i;
    
    for(i=0;i<n;i++){
        scanf("%lf",&b[i]);
    }    
    
}

void stampa_vettore(double *b,int n){
    
    int i;
    
    for(i=0;i<n;i++){
             printf("\n%25.17lf",b[i]);
             fflush(stdout);
             
    }

}  
    
