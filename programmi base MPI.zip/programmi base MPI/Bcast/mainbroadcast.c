#include <stdio.h>
#include <mpi.h>


void leggi_vettore(double *b,int n);
void stampa_vettore(double *b,int n);

int main (int argc, char *argv[]){

    double vett[6]={0,0,0,0,0,0};
    int nproc,me;
       
    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD,&nproc);
    MPI_Comm_rank(MPI_COMM_WORLD,&me);
    
    
    if (me==0){
        printf("\n Inserisci le 6 entrate del vettore vett:\n");
        fflush(stdout);
        leggi_vettore(vett,6);
    }
    
	MPI_Barrier(MPI_COMM_WORLD);
    	
    printf("\n Vettore vett sul processo %d",me);
    fflush(stdout);
    stampa_vettore(vett,6);

    MPI_Bcast(&vett[0],6,MPI_DOUBLE,0,MPI_COMM_WORLD);
    
    printf("\n Vettore vett sul processo %d",me);
    fflush(stdout);
    stampa_vettore(vett,6);
        
    

    MPI_Finalize();


}


void leggi_vettore(double *b,int n){

    int i;
   
    for(i=0;i<n;i++){
        scanf("%lf",&b[i]);
    }    
    
}

void stampa_vettore(double *b,int n){
    
    int i;
    
    for(i=0;i<n;i++){
             printf("\n%25.17lf",b[i]);
             fflush(stdout);
             
    }

}  
    

