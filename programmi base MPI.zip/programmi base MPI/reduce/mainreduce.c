#include <stdio.h>
#include <mpi.h>
int main(int argc, char *argv[])
{ 	int me, nproc;
	int sum, sumtot;
	MPI_Init(&argc,&argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&me);
	MPI_Comm_size(MPI_COMM_WORLD,&nproc);
	sum=nproc;
	sumtot=0;
	sum+=me;
	MPI_Reduce(&sum,&sumtot,1,MPI_INT,MPI_SUM,0,MPI_COMM_WORLD);
	printf("Sono %d sum=%d sumtot=%d\n",me,sum,sumtot);
	MPI_Finalize();
	/*system("PAUSE");*/
	return 0;
}
